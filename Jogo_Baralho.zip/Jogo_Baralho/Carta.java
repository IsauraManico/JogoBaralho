
package TrabalhoBaralho;

/**
 *
 * @author isaura
 */
public class Carta 
{
     private String simbolo_naipe;
     private String numero;
     
     public Carta (String numero, String simbolo_naipe)
     {
         this.numero = numero;
         this.simbolo_naipe = simbolo_naipe;
     }

    public String getNumero()
    {
        return numero;
    }

    public void setNumero(String numero) 
    {
        this.numero = numero;
    }

    public String getSimbolo_naipe()
    {
        return simbolo_naipe;
    }

    public void setSimbolo_naipe(String simbolo_naipe) 
    {
        this.simbolo_naipe = simbolo_naipe;
    }
    
    public String toString()
    {
        return ""+ "\n------Carta--------"+numero+"de"+simbolo_naipe+"\n";
    }
     
    
     
    
}
