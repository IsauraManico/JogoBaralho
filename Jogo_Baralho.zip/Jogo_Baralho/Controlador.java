
package TrabalhoBaralho;

import java.util.Scanner;

/** 
 *
 * @author isaura A.Manico 
 */
public class Controlador
{    
    
     public static Scanner input = new Scanner (System.in);
     private static Baralho baralho = new Baralho();
     static int c = 0;
    
  
     public static void inicializar()
     {
         
         
        baralho.addCarta("A", "Espadas");
        baralho.addCarta("2", "Espadas");
        baralho.addCarta("3", "Espadas");
        baralho.addCarta("4", "Espadas");
        baralho.addCarta("5", "Espadas");
        baralho.addCarta("6", "Espadas");
        baralho.addCarta("7", "Espadas");
        baralho.addCarta("8", "Espadas");
        baralho.addCarta("9", "Espadas");
        baralho.addCarta("10","Espadas");
        
        baralho.addCarta("A", "Copas");
        baralho.addCarta("2", "Copas");
        baralho.addCarta("3", "Copas");
        baralho.addCarta("4", "Copas");
        baralho.addCarta("5", "Copas");
        baralho.addCarta("6", "Copas");
        baralho.addCarta("7", "Copas");
        baralho.addCarta("8", "Copas");
        baralho.addCarta("9", "Copas");
        baralho.addCarta("10", "Copas");
        
        baralho.addCarta("A", "Ouros");
        baralho.addCarta("2", "Ouros");
        baralho.addCarta("3", "Ouros");
        baralho.addCarta("4", "Ouros");
        baralho.addCarta("5", "Ouros");
        baralho.addCarta("6", "Ouros");
        baralho.addCarta("7", "Ouros");
        baralho.addCarta("8", "Ouros");
        baralho.addCarta("9", "Ouros");
        baralho.addCarta("10", "Ouros");
        
        baralho.addCarta("A", "PAUS");
        baralho.addCarta("2", "PAUS");
        baralho.addCarta("3", "PAUS");
        baralho.addCarta("4", "PAUS");
        baralho.addCarta("5", "PAUS");
        baralho.addCarta("6", "PAUS");
        baralho.addCarta("7", "PAUS");
        baralho.addCarta("8", "PAUS");
        baralho.addCarta("9", "PAUS");
        baralho.addCarta("10", "PAUS");
        baralho.addCarta("j", "joker");
        baralho.addCarta("Q", "Ouros");
     
        
        
     }
     
       
     public static Object darCarta()
     {
        Object tmp = null;
        int v =42;
         
         if (v-1>0)
         {
             tmp = baralho.retirarCarta();
             c++;
         }
         
         return tmp;
     }
     
      public  static void vintUm()
     {
         int jogador =0;
         int pontosComput = 0;
         
         
         
         if ( c ==21 )
         {
             baralho.emBaralhar();
             
             System.out.println("O jogador Ganhou!");
         }
         else
         {
             System.out.println("Jogo Perdido");
         }
        
         
         
         
        
         
         
     }
     
     
     public static void menu()
     {
         int op;
         int sair = -1;
         
         do{
         System.out.println("Escolha uma opcao: 1-Inserir carta no baralho; 2-Retirar carta do Baralho"
                 + "3-Mostrar baralho; 4-Mostrar a carta do topo 5- embaralhar 6- Ver Cartas "
                 + " 7-Ver Resultado: 8-sair");
         op = input.nextInt();
         
         
      
         switch (op)
         {
             case 1:
                 System.out.println("<<------Inserir CARTA-------->>");
                 baralho.inserirCarta();
                 break;
             case 2:
                 System.out.println("<<--------Retirar Carta----------->>");
                 System.out.println("Retirar Carta:"+darCarta());
                 break;
             case 3:
                 System.out.println("<<----------Mostrar Baralho---------------->>");
                 System.out.println(""+baralho.toString());
                 System.out.println(""+ baralho.quant());
                 
                 break;
             case 4:
                  System.out.println("<<------------TOPO--------------------->>");
                  System.out.println("Topo:"+baralho.topo());
                 break;
             case 5:
                 baralho.emBaralhar();
                 //System.out.println(""+baralho.toString());
                 break;
             case 6:
                 inicializar();
                 break;
             case 7:
                 vintUm();
                 break;
            
             case 8:
                 System.exit(0);
                 break;
            
             default:
                 System.out.println("Operacao Invalida!");
         }
         
       
      }while(op !=sair);
        
         
     }
    
    public static void main(String[] args) 
    {
    
      
        
        menu();
        
       
    }
}
