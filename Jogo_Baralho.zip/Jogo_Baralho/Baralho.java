
package TrabalhoBaralho;


import java.util.Scanner;


/**
 *
 * @author isaura
 */
public class Baralho 
{
    
    static Scanner input = new Scanner ( System.in);
    
    static int cont = 0;
    
    static String numero;
    static String simb;
    
    public Pilha1<Carta> cartas = new Pilha1<>();
     public static Object temp;
     public static Object[] v = new Object[42];
     
    
    //Assim o trabalho foi criado e ja sera inicializado com as cartas padrao
    public Baralho ()
    {
        System.out.println("<<---------------------------JOGO DO BARALHO-------------------------------------->>");
           // inserirCarta();
          // System.out.println(""+toString());
        
    }
    
    //Funcao iniciar baralho com as cartas padroes
    
    //funcao responsavel por criarbe armazenar as cartas
    
    public void addCarta(String numero, String simbolo_naipe)
    {
        //criando uma nova carta com um numero e simbolo
        
        Carta novaCarta = new Carta(numero, simbolo_naipe);
        cartas.empilha(novaCarta);
         cont ++;
        
    }
    
    
    //Funcao inserir carta no baralho
    public void inserirCarta()
     {
         int n;
         
         
         //System.out.println("Quantas cartas pretendes inserir?");
         //n = input.nextInt();
         
        for ( int i = 0; i<2 ;i++)
         {
             System.out.println("Insira um numero: A 2,3,4,5,6,7,8,9,10,J,K");
             numero = input.next();
             
             System.out.println("Insira um simbolo: OURO PAUS COPAS ESPADAS");
             simb = input.next();
            
             
             Carta c = new Carta(numero,simb);
              
            cartas.empilha(c);
            
            cont ++;
               
         }
         System.out.println(" "+ cartas.toString());
             
            
         
     }
    
     public int quant()
     {
         return cartas.quantElem();
     }
     
     public Object topo()
     {
         return cartas.elemTop();
     }
     
     public Object retirarCarta()
     {
         return cartas.desempilha();
     }
     
    //Desafios
     
     public void emBaralhar()
     {
         int j =0;
         String r = "";
         if ( cont == 42)
         {
             for ( int c = 0;c<42;c++)
             {
                  int i = (int )Math.round(Math.random()*41);
                 this.v[j] = cartas;
                 temp = v[j];
                 v[j] = v[i];
                 v[i]= v[c];
                 v[c] = temp;
                 
                 r+= v[c];
                 
             }
             
             System.out.println(""+r);
         }
     }
     
     
    
    
     
    
   
  
   
   
    public String toString()
    {
        StringBuilder retorno = new StringBuilder();
       
        
        retorno.append(cartas );
       
       
       return retorno.toString() +"";
    }
}

