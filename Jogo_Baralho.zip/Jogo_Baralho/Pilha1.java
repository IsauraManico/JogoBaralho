package TrabalhoBaralho;

/*


Autor: Isaura A.Manico

Estrutura de Dados: Pilha: LIFO: last input first output

Implementação da classe Pilha
*/

public class Pilha1<T> //Classe do tipo generica
{
	//Declarations
	
	private T[] item;  // Aonde vai conter os elementos
	private int topo;   //vai apontar para o topo
	public int tot ;     //total de elementos na pilha
	
	//operacoes
        
        public Pilha1() //metodo construtor
        {
            this(42);  //capacidade de 42 elementos
        }
	
	public Pilha1 ( int maxTam) //construtor que recebe o tamanho
	{
		this.item =(T[]) new Object[maxTam];  //cria o objecto
		this.topo = 0;   //inicializa o topo
	}
	
	public void empilha ( T x)   //metodo que adiciona elemento no final da pilha 
	{
		if( this.topo == this.item.length)
		{
			System.out.println("Erro : a pilha esta cheia");
		}
		else
		{
			this.item[this.topo++] = x;
			this.tot++;
			
			System.out.println("Empilhar:"+x);
		
		}
	
	}
	
	public Object desempilha()  //metodo que reira elemento da pilha
	{
		if ( this.vazia())
		{
			System.out.println (" Erro: a pilha esta vazia!");
		
		}
		this.tot--;
		
		return this.item[ --this.topo] ;
		
		
		
		
	
	}
	
	public int tamanho() 
	{
		return this.topo;
	}
	
	public T elemTop() //metodo que retorna o elemento que esta no topo
	{
		return this.item[this.tot-1];
	}
	
	public int quantElem() //retorna o total de elemntos
	{
		return this.tot;
	}
	
	public String toString() //imprrime os elementos da pilha
	{
		StringBuilder s = new StringBuilder();
		s.append("[");
		
		for (int i=0; i<this.tot-1; i++)
                {
			s.append(this.item[i]);
			s.append(", ");
		}
		
		if (this.tot>0)
                {
			s.append(this.item[this.tot-1]);
		}
                
                return s.toString() +"]";
	
	}
	
	public boolean vazia()  //verifica se a pilha esta vazia
	{
		return  (this.topo == 0);
	}



}
